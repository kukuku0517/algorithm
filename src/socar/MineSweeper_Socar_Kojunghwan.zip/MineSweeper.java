package socar;

import java.util.Scanner;

public class MineSweeper {

    static int[] dx = {-1, 0, 1, -1, 1, -1, 0, 1};
    static int[] dy = {-1, -1, -1, 0, 0, 1, 1, 1};
    static final int ROW = 10;
    static final int COL = 10;
    static final int COUNT = 10;
    static final int[][] MAP = new int[ROW][COL];

    /**
     * Scanner를 통해 입력 받음
     * <p>
     * case 0 : 지뢰를 랜덤 생성
     * case 1 : 10쌍의 지뢰 좌표 (x,y)를 추가로 입력 (중복은 없다고 가정)
     **/

    //      dummy data
    //      1
    //      1 7 6 4 5 9 8 7 3 2 9 6 4 3 6 5 8 9 6 0
    public static void main(String args[]) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("(0) 자동생성 / (1) 직접입력 :");
        int command = scanner.nextInt();
        if (command == 0) { // 지뢰 랜덤 생성
            randomGenerateMines();
            printMines();
        } else if (command == 1) { // 지뢰 위치 입력
            for (int i = 0; i < COUNT; i++) {
                int x = scanner.nextInt();
                int y = scanner.nextInt();
                if (!inRange(x, y)) {
                    throw new Exception("좌표가 범위에서 벗어났습니다.");
                }
                generateMine(x, y);
            }
            printMines();
        } else {
            throw new Exception("유효하지 않은 입력입니다.");
        }
    }

    /**
     * @param x
     * @param y
     * @return (x, y)에 지뢰 유무를 반환한다
     **/
    static boolean hasMine(int x, int y) {
        if (MAP[x][y] == -1) {
            return true;
        }
        return false;
    }

    /**
     * @param x
     * @param y
     * @return (x, y)의 좌표가 유효한지 여부를 반환한다
     */
    static boolean inRange(int x, int y) {
        if (x >= 0 && y >= 0 && x < ROW && y < COL) {
            return true;
        }
        return false;
    }

    /**
     * @param x
     * @param y
     * @return (x, y)에 지뢰를 생성하고, 주변 좌표를 update 한다
     **/
    static void generateMine(int x, int y) throws Exception {
        if (hasMine(x, y)) {
            throw new Exception("지뢰가 중복배치 되었습니다.");
        }
        MAP[x][y] = -1;
        for (int i = 0; i < 8; i++) {
            int nx = x + dx[i];
            int ny = y + dy[i];
            if (inRange(nx, ny) && !hasMine(nx, ny)) {
                MAP[nx][ny]++;
            }
        }
    }


    /**
     * 지뢰를 자동 생성한다
     **/
    static void randomGenerateMines() throws Exception {
        int countLeft = COUNT;
        while (countLeft > 0) {
            int rand = (int) (Math.random() * ROW * COL);
            int x = rand / ROW;
            int y = rand % ROW;
            if (!hasMine(x, y)) {
                generateMine(x, y);
                countLeft--;
            }
        }
    }

    /**
     * "*"  : 지뢰있음
     * "숫자" : 주변 지뢰 갯수
     **/
    static void printMines() {
        for (int i[] : MAP) {
            for (int j : i) {
                if (j == -1) {
                    System.out.printf(" * ");
                } else {
                    System.out.printf("%2d ", j);
                }
            }
            System.out.println();
        }
    }
}
